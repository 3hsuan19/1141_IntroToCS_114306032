import java.util.Scanner;

public class Lab4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Q1");
		Scanner sc = new Scanner(System.in);
		int layer = sc.nextInt();
		int newLayer = layer - 1;
        for (int i = 0; i < layer; i++){
            for (int j = i; j < layer - 1; j++) {
                System.out.print(" ");
            }
            for (int j = 0; j < 2 * i + 1; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
        for (int i = newLayer ; i >= 0; i--) {
        	for (int j = i - 1; j < newLayer; j++ ) {
        		System.out.print(" ");
        	}
        	for (int j = 0; j < 2 * i - 1; j++) {
        		System.out.print("*");
        	}
        	System.out.println();
        }
        
        System.out.println("Q2");
        int oddSum = 0, evenSum = 0;
        int oddCount = 0, evenCount = 0;
        double oddAvg = 0.0, evenAvg = 0.0;
        
        while (sc.hasNextInt()) {
        	int num = sc.nextInt();
        	if (num % 2 == 0) {
        		evenSum += num;
        		evenCount++;
        	}
        	else {
        		oddSum += num;
        		oddCount++;
        	}
        	if (evenCount > 0) {
        		evenAvg = (double)evenSum / evenCount;
        	}
        	else {
        		evenAvg = evenSum;
            }
        	if (oddCount > 0) {
        		oddAvg = (double)oddSum / oddCount;
        	}
        	else {
        		oddAvg = oddSum;
        	}
      
        
        }
        System.out.println(oddSum + " " + oddAvg );
        System.out.println(evenSum + " " + evenAvg);
        sc.close();
 


	    }
}



